<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ClassroomRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => ($this->isMethod('PATCH') ? 'sometimes|' : '').'required|string|min:2|max:255',
            'vacancies' => ($this->isMethod('PATCH') ? 'sometimes|' : '').'required|integer|min:1|max:500',
            'course_id' => ($this->isMethod('PATCH') ? 'sometimes|' : '').'required|integer|exists:courses,id',
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'O campo nome é obrigatório.',
            'name.string' => 'O campo nome deve conter caracteres.',
            'name.min' => 'O campo nome deve ter no mínimo :min caracteres.',
            'name.max' => 'O campo nome deve ter no máximo :max caracteres.',
            'vacancies.required' => 'O campo vagas é obrigatório.',
            'vacancies.numeric' => 'O campo vagas deve ser um número.',
            'vacancies.min' => 'O campo vagas deve ser no mínimo :min.',
            'vacancies.max' => 'O campo vagas deve ser no máximo :max.',
        ];
    }
}
